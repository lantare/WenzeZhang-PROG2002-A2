# Harbour Hope Community Events Portal

This project is a complete PROG2002 Assessment 2 implementation. It contains a MySQL schema, a read-only Node.js and Express REST API, and a responsive HTML, CSS and JavaScript client for browsing and searching charity events.

Personal details and external links remain as placeholders in `submission/PROG2002_A2_Report.docx`. Replace every value in square brackets before submission.

## Project structure

```text
PROG2002_A2/
  api/                 MySQL schema, Node.js API and tests
  client/              Responsive browser client
  documentation/       Stage plan, demo script and test checklist
  stage-packages/      Three incremental submission snapshots
  submission/          Final report and required source ZIP files
```

## Prerequisites

- Node.js 18 or newer
- pnpm 9 or newer (`corepack enable` can enable pnpm on recent Node.js releases)
- MySQL 8.x
- A modern browser

The client uses the Lucide icon script from `https://unpkg.com`, so an internet connection is needed for icons. The pages and content still work if that script is unavailable.

## First-time database setup

1. Open `api/database/charityevents_db.sql` and replace `change_this_password` with a private local password.
2. Import the script with MySQL Workbench, or run the following from a terminal that has `mysql` on PATH:

```cmd
mysql -u root -p < api\database\charityevents_db.sql
```

The script recreates `charityevents_db`, creates the three related tables, loads 11 sample events, and grants a read-only account access to the database. Because the script begins with `DROP DATABASE IF EXISTS`, do not run it against a database that contains work you need to keep.

## Configure and run the API

```powershell
cd .\api
Copy-Item .env.example .env
```

Open `.env` and set `DB_PASSWORD` to the password used in the SQL script. Keep the remaining defaults unless MySQL uses a different host or port.

```powershell
pnpm install
pnpm test
pnpm start
```

The API runs at `http://localhost:3000`. Verify the real database connection by opening `http://localhost:3000/api/health`; it should return a JSON response containing `"status":"ok"` and `"database":"connected"`.

## Run the client

Open a second terminal:

```powershell
cd .\client
pnpm start
```

Open `http://localhost:5500`. Keep both terminals running. The API allows requests from this client origin by default.

## Main API endpoints

- `GET /api/health`
- `GET /api/organization`
- `GET /api/categories`
- `GET /api/events`
- `GET /api/events?includePast=true`
- `GET /api/events/search?date=2026-10-18&location=Harbour&category=1`
- `GET /api/events/:id`

All endpoints are intentionally read-only because create, update, delete and ticket-purchase operations are deferred to Assessment 3.

## Before submission

1. Complete all square-bracket placeholders in the report, including student details, GitHub URL, SCU OneDrive video URL and required declaration.
2. Create a private GitHub repository, add the marker as a collaborator if required, and push the three stages as separate, descriptive commits. Do not upload all stages at once and claim they were historical commits.
3. Run the live MySQL health check, API tests and browser checklist in `documentation/TEST_CHECKLIST.md`.
4. Rename the two final ZIP files in `submission` by replacing `USERNAME` with your actual username.
5. Upload the report, the two ZIP files, the GitHub link and the video link to Blackboard.

## Troubleshooting

- `API startup failed`: confirm MySQL is running and the `.env` credentials match the SQL script.
- `Could not contact the API`: start the API on port 3000 and the client on port 5500.
- CORS error: confirm `CLIENT_ORIGIN=http://localhost:5500` in `api/.env`.
- Port already in use: stop the other process or change both the server port and the matching configuration.
- Empty search: use at least one filter. The included date `2026-10-18`, location `Harbour`, and category `Fun Run` should find the sample fun run.
